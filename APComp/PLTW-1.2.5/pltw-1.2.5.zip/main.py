"""
Ben Campbell 10/06/22
PLTW 1.2.5
Turtle Project
Little 2d goal scoring game
"""
import graphics
import game

#Make a game window object
game_window = graphics.GameWindow(0, 0)

#Start the game main loop
game_window.start_main()

#Start the window mainloop
game_window.window.mainloop()
